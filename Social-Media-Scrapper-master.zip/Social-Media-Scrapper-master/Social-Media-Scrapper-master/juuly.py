from src.InstagramScrapper import InstagramScrapper
from src.TwitterScrapper import TwitterScrapper

from clarifai.rest import ClarifaiApp
from clarifai.rest import Image as ClImage

from fbchat import Client
from fbchat.models import *




if __name__ == '__main__':
	app = ClarifaiApp(api_key='067b23ae7c444fd08dbbee13d719950f')
	model = app.models.get('ecig')
	model.model_version = '1c1a893c1bac4fabbf8873b767952ee3'

	numbers = ['1', '2', '3', '4', '5', '6', '7', '8', '9', '10']
	amount_vaping = 0
	insta_limit = 9
	
	print("Starting Social Media Scrapper...")
	keyword = str(input("Enter an Instagram username to search for: "))
	name = str(input("Enter the person's name: "))
	scrapper = InstagramScrapper()
	scrapper.Scrape_Instagram(tag=keyword,
							limit=insta_limit,
							browser='chrome') # 'chrome' or 'firefox'

	print("Stopping Social Media Scrapper...")
	file_path = 'C:/Users/mehal/Documents/Social-Media-Scrapper-master/Social-Media-Scrapper-master/data/data_' + keyword + '/img'
	for x in range(insta_limit):
		picture = file_path + "/" + "Instagram_" + numbers[x] + '.jpeg'
		image = ClImage(file_obj=open(picture, 'rb'))
		prediction = model.predict([image])
		value = prediction['outputs'][0]['data']['concepts'][0]['value']
		print(value)
		if value > .05:
			amount_vaping += 1
	print(amount_vaping)
	if(amount_vaping >= 2):
		client = Client('juulythebear@gmail.com','JerryisA1')
		user = client.searchForUsers(name)[0]
		message_id = client.send(Message(text="Hi! I'm Juuly The Bear. I am messaging you to tell you that you are on notice for Juuling too much, and that you might be addicted. Using our advanced machine learning software, we have deduced this. Please take notice. Juuling is extremely bad for your health. We would like you to give it up."), thread_id=user.uid, thread_type=ThreadType.USER)

	
	
